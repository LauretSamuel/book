<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/css?family=Gentium+Book+Basic&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style_page_accueil_vitrine.css">
    <script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="javascript/javascript.js"></script>
    <title>Page_vitrine_accueil</title>
</head>
<body>
    <header>
    <img src="image/book.png" alt="" width="200px">
    <form class="form">
    <input type="search" class="search" placeholder="Rechercher">
    <div class="div_icon_search">
    <input type="image" src="image/search.png" class="icon_search">
    </div>
    </form>
    <div id="hover_compte">
    <a href="" class="compte"><h4 class="nom_compte" >Bienvenue Josiane</h4>
    <p class=" nom_compte">Mon compte</p>
    <i class="down"></i></a>
    </div>
    <div class="deroulant_compte" id="deroulant">
        <ul class="ul_cacher">
            <a href="#" class="li_a"><li class="li_cacher">Profil</li></a>
            <a href="#" class="li_a"><li class="li_cacher">Mes réservation</li></a>
        </ul>
    </div>
    <div>
        <a href="#" class="panier_caddy">
        <img src="image/caddy.png" alt="" width="50px">
        <h5 class="panier">Panier</h5>
        </a>
    </div>
    </header>

    <div class="contenue">

    </div>
</body> 

</html>