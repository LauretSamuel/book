
$(document).ready(function(){
$("#hover_compte").mouseenter(function(){
    $(".deroulant_compte").show();
});

$(".ul_cacher").mouseenter(function() {
    $(".ul_cacher").show();
})
$(".ul_cacher").mouseleave(function() {
    $(".deroulant_compte").hide();
})
});